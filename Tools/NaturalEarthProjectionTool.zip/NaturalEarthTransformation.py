###################################################################################
# Natural Earth transformation script for ArcMap tool
#
# This script projects shapefiles with the GCS_WGS_1984 reference into the Natural
# Earth or Natural Earth II projection. The script uses an open source module
# called shapefile.py (resource: http://code.google.com/p/pyshp/). The module file
# should be stored in the same folder as this script.
#
# Author: Bojan Savric
# Date: 3/20/2013
###################################################################################

# Importing libraries and modules
import shapefile
import math
import arcpy

# Defining constant values
RO_VALUE = math.pi/180.0
RADIUS = 6371000 #radius of the authalic sphere in meters


###################################################################################
# Function that transforms any geographic coordinates to Natural Earth projection.
#
# Input:
#   point - A list with two elements. First element is longitude and second element
#           is latitude. Units of both are degrees.
#
# Output:
#   [x,y] - Cartesian coordinates of projected point.

def NaturalEarth1(point):
    phi = point[1]*RO_VALUE
    lam = point[0]*RO_VALUE
    phi2 = phi*phi
    phi4 = phi2*phi2

    x = RADIUS*lam*(0.8707 + phi2*(-0.131979 + phi2*(-0.013791 + phi4*phi2*(0.003971 - phi2*0.001529))))
    y = RADIUS*phi*(1.007226 + phi2*(0.015085 + phi4*(-0.044475 + 0.028874*phi2 -0.005916*phi4)))
    
    return [x,y]

# End of function...
###################################################################################

###################################################################################
# Function that transforms any geographic coordinates to Natural Earth II
# projection.
#
# Input:
#   point - A list with two elements. First element is longitude and second element
#           is latitude. Units of both are degrees.
#
# Output:
#   [x,y] - Cartesian coordinates of projected point.

def NaturalEarth2(point):
    phi = point[1]*RO_VALUE
    lam = point[0]*RO_VALUE
    phi2 = phi*phi
    phi4 = phi2*phi2
    phi6 = phi4*phi2
    
    x = RADIUS*lam*(0.84719 - 0.13063*phi2 + phi6*phi6*(-0.04515 + 0.05494*phi2 - 0.02326*phi4 + 0.00331*phi6))
    y = RADIUS*phi*(1.01183 + phi4*phi4*(-0.02625 + 0.01926*phi2 - 0.00396*phi4))
    
    return [x,y]

# End of function...
###################################################################################

###################################################################################
# Function that converts a string into a raw string. Function returns a raw string
# presentation of text.
# Source: http://code.activestate.com/recipes/65211/
#
# Input:
#   text - any string variable
#
# Output:
#   new_string - raw string representation of input text

escape_dict={'\a':r'\a', '\b':r'\b', '\c':r'\c', '\f':r'\f', '\n':r'\n', '\r':r'\r', '\t':r'\t',
             '\v':r'\v', '\'':r'\'', '\"':r'\"', '\0':r'\0', '\1':r'\1', '\2':r'\2', '\3':r'\3',
             '\4':r'\4', '\5':r'\5', '\6':r'\6', '\7':r'\7', '\8':r'\8', '\9':r'\9'}

def raw(text):
    """Returns a raw string representation of text"""
    new_string=''
    for char in text:
        try: new_string+=escape_dict[char]
        except KeyError: new_string+=char
    return new_string

# End of function...
###################################################################################


###################################################################################
# Function that replaces one backslash with two backslashes.
#
# Input:
#   PathString - raw string of used file path
#
# Output:
#   "string variable" - path string where one backslash is replaced with two

def CorrectingPath(PathString):
    return PathString.replace("\\","\\\\")

# End of function...
###################################################################################


###################################################################################
# MAIN SCRIPT CODE
###################################################################################

#Main try/except block
try:
    try:
    #Storing ArcGIS parameters
	shp_input = str(arcpy.GetParameterAsText(0))
	shp_input = CorrectingPath(raw(shp_input))
	shp_output = arcpy.GetParameterAsText(1)
	shp_output = CorrectingPath(raw(shp_output))
	lon0 = arcpy.GetParameterAsText(2)
	projection = arcpy.GetParameterAsText(3)
    except: 
	raise RuntimeError("** Error: Impossible to store arguments from the ArcMap Tool. **\n")
    

    #Testing passed arguments from ArcMap tool
    arcpy.AddMessage("Testing input shapefile and other arguments...") #Process message for user
    
    #Testing for comma/period for central meridian's longitude
    try:
	Longitude0 = float(lon0.replace(",","."))
    except:
	raise RuntimeError("** Error: Passed central meridian value is incorrect. **\n")
    
    
    #Test if input shapefile has correct spatial reference
    spatialRef = arcpy.Describe(shp_input).spatialReference
    #Checking reference name
    if spatialRef.name != "GCS_WGS_1984":
        raise RuntimeError("** Error: Incorrect spatial reference name! Only GCS_WGS_1984 is allowed. **\n")
    #Checking geographic coordinate system name
    if spatialRef.GCSName != "GCS_WGS_1984":
        raise RuntimeError("** Error: Incorrect geographic coordinate system name! Only GCS_WGS_1984 is allowed. **\n")
    #Checking projection name (there should be no projection)
    if spatialRef.projectionName != "":
        raise RuntimeError("** Error: Incorrect projection name! **\n")
    #Checking angular units
    if spatialRef.angularUnitName != "Degree":
        raise RuntimeError("** Error: Incorrect angular unit! **\n")
    
    #Test passed successfully:
    arcpy.AddMessage("Input shapefile has correct spatial reference...") #Process message for user
    
    
    #New projection test
    if (projection != "Natural Earth" and projection != "Natural Earth II"):
	raise RuntimeError("** Error: Incorrect name of the new projection! **\n")
    
    
    #Central latitude test
    if abs(Longitude0) > 180.0:
        raise RuntimeError("** Error: Incorrect central meridian! **\n")
    
    #Checking if input shapefile has applied some other central meridian
    if spatialRef.longitude != 0.000:
	#Correcting central meridian value
        Longitude0 -= spatialRef.longitude
	#Assigning right convergence angle
	if Longitude0 < -180.0:
	    Longitude0 += 360.0
	elif Longitude0 > 180.0:
	    Longitude0 -= 360.00
        arcpy.AddMessage("Input shapefile does not have Greenwich as central meridian.\nPasted central latitude was therefore corrected...") #Process message for user

    
    #Opening the input shapefile
    arcpy.AddMessage("Reading shapefile...") #Process message for user
    sf_e = shapefile.Editor(shp_input)
    
    #Checking if shifting is needed
    #If data are points or longitude0 is 0, shifting is not needed
    flag = 1
    if ((sf_e.shapeType in (1,8,11,18,21,28)) or\
        (Longitude0 == 0.00)):
        flag = 0
    
    #Preparing data for shifting on central meridian
    if flag == 1:
        arcpy.AddMessage("Some data preparation is needed...") #Process message for user
        #Defining cutting meridian
        if Longitude0 > 0:
            LongitudeCut = Longitude0 - 180.0
        if Longitude0 < 0:
            LongitudeCut = Longitude0 + 180.0
        
        #Creating clipping boxes
        arcpy.AddMessage("Clipping data for shifting meridians...") #Process message for user
	#Creating clipping polygon for west side
        w = shapefile.Writer(shapefile.POLYGON)
        w.poly(parts=[[[-181,91],[LongitudeCut-0.0000001,91],[LongitudeCut-0.0000001,-91],[-181,-91],[-181,91]]])
        w.field('PART','C','5')
        w.record('West')
        w.save('C:\\TEMP\\ClippingBoxWest')
        
        #Creating clipping polygon for east side
        e = shapefile.Writer(shapefile.POLYGON)
        e.poly(parts=[[[181,-91],[LongitudeCut+0.0000001,-91],[LongitudeCut+0.0000001,91],[181,91],[181,-91]]])
        e.field('PART','C','5')
        e.record('East')
        e.save('C:\\TEMP\\ClippingBoxEast') 
        
        #Clipping data
        arcpy.Clip_analysis(shp_input,"C:\\TEMP\\ClippingBoxEast.shp","C:\\TEMP\\ClippedEast.shp")
        arcpy.Clip_analysis(shp_input,"C:\\TEMP\\ClippingBoxWest.shp","C:\\TEMP\\ClippedWest.shp")
    
        #Merging clipped data together
        arcpy.Merge_management(["C:\\TEMP\\ClippedEast.shp", "C:\\TEMP\\ClippedWest.shp"],"C:\\TEMP\\MeargedLayer.shp")
        #Fixing density of clipped polygons
        arcpy.AddMessage("Densifying clipped data...") #Process message for user
        arcpy.Densify_edit("C:\\TEMP\\MeargedLayer.shp","DISTANCE","0.2 DecimalDegrees","0.0000009 DecimalDegrees","10")    
    
        #Updating shapefile to be projected
        sf_e = shapefile.Editor("C:\\TEMP\\MeargedLayer.shp")
    
    #Projecting data - loop through the shapes and points
    numRecords = len(sf_e._shapes)
    arcpy.AddMessage(projection + " projection will be applied.\nProjecting data...") #Process message for user
    for i in range(0,numRecords):
        j = 0
        for point in sf_e._shapes[i].points:
            #Applying central meridian shift
            if (Longitude0 != 0):
                lam = point[0] - Longitude0
                if lam > 180.00:
                    lam -= 360.0
                if lam < -180.00:
                    lam += 360.0
            else:
                lam = point[0]
            #Applying correct projection
            if projection == "Natural Earth II":
                NE_point = NaturalEarth2([lam, point[1]])
            else:
                NE_point = NaturalEarth1([lam, point[1]])
            #Storing new coordinates into a shapefile
            sf_e._shapes[i].points[j] = NE_point
            j+=1
    
    #Saving new projected data into output shapefile
    arcpy.AddMessage("Saving new shapefile...") #Process message for user
    sf_e.save(shp_output)
    
    #Cleaning temporary files if the flag is on
    if flag == 1:
        arcpy.AddMessage("Deleting temporary shapefiles...") #Process message for user
        arcpy.Delete_management("C:\\TEMP\\MeargedLayer.shp")
        arcpy.Delete_management("C:\\TEMP\\ClippedEast.shp")
        arcpy.Delete_management("C:\\TEMP\\ClippedWest.shp")
        arcpy.Delete_management("C:\\TEMP\\ClippingBoxWest.shp")
        arcpy.Delete_management("C:\\TEMP\\ClippingBoxEast.shp")
    
    arcpy.AddMessage("Script has successfully projected input shapefile!") #Process message for user
    
#RuntimeError exceptions
except RuntimeError as y:
	arcpy.AddMessage("***ERROR OCCURRED!!!***\n" + format(y)) #Prompt message for user
	
#Other exceptions
except Exception as x:
	arcpy.AddMessage("***ERROR OCCURRED!!!***\nMessage from the system: " + format(x)) #Prompt message for user
